﻿using Renci.SshNet;
using System;

namespace SFTPConnectionApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {


                using (SftpClient client = new SftpClient("ftp.dneg.com", 2222, "ims-workday", "qnU6ND8Zckt88gmzRo"))
                {
                    client.Connect();

                    client.Disconnect();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
